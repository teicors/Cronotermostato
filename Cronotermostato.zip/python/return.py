def func():
    print {'4': 5, '6': 7}
func()
