#include <user_config.h>
#include <SmingCore/SmingCore.h>

#include "configuration.h"
#include <Libraries/CronLibrary/Cron.h>

HttpServer server;

bool serverStarted = false;
extern String alarmtime, sleeptime;
extern int sleepenabled,alarmenabled, buzzerenabled;
//extern void setpwn(int led0);
extern void sendData();
extern Cron cron;
extern CronoTempConfig CronoTempCfg;
extern LampMessage LampMsg;

// If you want, you can define WiFi settings globally in Eclipse Environment Variables
#ifndef WIFI_SSID
	#define WIFI_SSID "PleaseEnterSSID" // Put you SSID and Password here
	#define WIFI_PWD "PleaseEnterPass"
#endif


void onIndex(HttpRequest &request, HttpResponse &response)
{
    TemplateFileStream *tmpl = new TemplateFileStream("index.html");
    auto &vars = tmpl->variables();
    vars["temperature"] = CronoTempCfg.temperature;
    vars["noicetemp"] = CronoTempCfg.noicetemp;
    vars["welltemp"] = CronoTempCfg.welltemp;
    vars["stringtime1"] = CronoTempCfg.stringtime1;
    vars["stringtime2"] = CronoTempCfg.stringtime2;
    vars["stringtime3"] = CronoTempCfg.stringtime3;
    vars["stringtime4"] = CronoTempCfg.stringtime4;
    vars["stringtime5"] = CronoTempCfg.stringtime5;
    vars["stringtime6"] = CronoTempCfg.stringtime6;
    vars["stringtime7"] = CronoTempCfg.stringtime7;
    debugf("Send Home Page");
    response.sendTemplate(tmpl);
}

void onConfiguration(HttpRequest &request, HttpResponse &response)
{
//    LampConfig cfg = loadConfig();
    loadConfig();
    if (request.method == HTTP_POST)
    {
            debugf("Update config");
            // Update config
            if (request.getPostParameter("SSID").length() > 0) // Network
            {
                    CronoTempCfg.NetworkSSID = request.getPostParameter("SSID");
                    CronoTempCfg.NetworkPassword = request.getPostParameter("Password");
            }
            saveConfig();
//            startWebClock(); // Apply time zone settings
            response.redirect("/");
    }

    debugf("Send template");
    TemplateFileStream *tmpl = new TemplateFileStream("config.html");
    auto &vars = tmpl->variables();
    vars["SSID"] = CronoTempCfg.NetworkSSID;
    response.sendTemplate(tmpl);
}

void onFile(HttpRequest &request, HttpResponse &response)
{
    String file = request.getPath();
    if (file[0] == '/')
            file = file.substring(1);

    if (file[0] == '.')
            response.forbidden();
    else
    {
            response.setCache(86400, true); // It's important to use cache for better performance.
            response.sendFile(file);
    }
}

/// API ///

void onApiDoc(HttpRequest &request, HttpResponse &response)
{
        TemplateFileStream *tmpl = new TemplateFileStream("api.html");
        auto &vars = tmpl->variables();
        vars["IP"] = (WifiStation.isConnected() ? WifiStation.getIP() : WifiAccessPoint.getIP()).toString();
        response.sendTemplate(tmpl);
}

void onApiStatus(HttpRequest &request, HttpResponse &response)
{
    JsonObjectStream* stream = new JsonObjectStream();
    JsonObject& json = stream->getRoot();
    json["status"] = (bool)true;
    JsonObject& sensors = json.createNestedObject("sensors");
    sensors["temperature"] = CronoTempCfg.temperature;
    sensors["noicetemp"] = CronoTempCfg.noicetemp;
    sensors["welltemp"] = CronoTempCfg.welltemp;
    sensors["stringtime1"] = CronoTempCfg.stringtime1;
    sensors["stringtime2"] = CronoTempCfg.stringtime2;
    sensors["stringtime3"] = CronoTempCfg.stringtime3;
    sensors["stringtime4"] = CronoTempCfg.stringtime4;
    sensors["stringtime5"] = CronoTempCfg.stringtime5;
    sensors["stringtime6"] = CronoTempCfg.stringtime6;
    sensors["stringtime7"] = CronoTempCfg.stringtime7;
    response.sendJsonObject(stream);
}


void onReboot(HttpRequest &request, HttpResponse &response)
{
    System.restart();
}


void startWebServer()
{
    if (serverStarted) return;

    server.listen(80);
    server.addPath("/", onIndex);
    server.addPath("/api", onApiDoc);
    server.addPath("/api/status", onApiStatus);
//    server.addPath("/api/output", onApiOutput);    
//    server.addPath("/config", onConfiguration);
    server.addPath("/reboot", onReboot);
    server.setDefaultHandler(onFile);
    serverStarted = true;

    if (WifiStation.isEnabled())
            debugf("STA: %s", WifiStation.getIP().toString().c_str());
    if (WifiAccessPoint.isEnabled())
        debugf("AP: %s", WifiAccessPoint.getIP().toString().c_str());
}

/// FileSystem Initialization ///

Timer downloadTimer;
HttpClient downloadClient;
int dowfid = 0;
void downloadContentFiles()
{
        debugf("DownloadContentFiles");

        downloadClient.downloadFile("http://simple.anakod.ru/templates/MeteoControl/MeteoControl.html", "index.html");
        downloadClient.downloadFile("http://simple.anakod.ru/templates/MeteoControl/MeteoConfig.html", "config.html");
        downloadClient.downloadFile("http://simple.anakod.ru/templates/MeteoControl/MeteoAPI.html", "api.html");
        downloadClient.downloadFile("http://simple.anakod.ru/templates/bootstrap.css.gz");
        downloadClient.downloadFile("http://simple.anakod.ru/templates/jquery.js.gz", (RequestCompletedDelegate)([](HttpConnection& connection, bool success) -> int {
                if(success) {
                        startWebServer();
                }
        }));
}
