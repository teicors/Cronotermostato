#ifndef INCLUDE_WEBSERVER_H_
#define INCLUDE_WEBSERVER_H_


void startWebServer();
void downloadContentFiles();
void flashleds();
#endif /* INCLUDE_WEBSERVER_H_ */
